// Minimal JS (bo'sh)
